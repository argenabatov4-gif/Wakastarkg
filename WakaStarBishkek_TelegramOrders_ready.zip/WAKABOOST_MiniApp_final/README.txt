WakaStarBishkek Telegram Mini App

В проекте настроена отправка заказов в Telegram через серверный endpoint /api/order.

Схема:
Mini App → /api/order → Telegram Bot API → ваш Telegram или группа менеджеров.

Настройка переменных окружения Vercel:
TELEGRAM_BOT_TOKEN
TELEGRAM_ADMIN_CHAT_ID

Подробная инструкция: SETUP_TELEGRAM.txt
