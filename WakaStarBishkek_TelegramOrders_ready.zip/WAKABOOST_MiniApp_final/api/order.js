export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  try {
    const body = req.body || {};
    const name = String(body.name || "").trim();
    const phone = String(body.phone || "").trim();
    const address = String(body.address || "").trim();
    const items = Array.isArray(body.items) ? body.items : [];
    const total = Number(body.total) || 0;
    const bonuses = Number(body.bonuses) || 0;
    const telegramUser = body.telegramUser || null;

    if (!name || !phone || !address) {
      return res.status(400).json({ error: "Заполните имя, телефон и адрес" });
    }
    if (!items.length) {
      return res.status(400).json({ error: "Корзина пуста" });
    }

    const token = process.env.TELEGRAM_BOT_TOKEN;
    const chatId = process.env.TELEGRAM_ADMIN_CHAT_ID;
    if (!token || !chatId) {
      return res.status(500).json({ error: "Telegram is not configured" });
    }

    const lines = items.map((x) => {
      const itemName = String(x.name || "Товар");
      const flavor = x.flavor ? ` — ${String(x.flavor)}` : "";
      const qty = Number(x.qty) || 0;
      const price = Number(String(x.price || 0).replace(/\s/g, "")) || 0;
      return `• ${itemName}${flavor} × ${qty} = ${price * qty} сом`;
    }).join("\n");

    const tg = telegramUser && (telegramUser.username || telegramUser.first_name)
      ? `\n👤 Telegram: ${telegramUser.username ? "@" + telegramUser.username : telegramUser.first_name}`
      : "";

    const text = [
      "🛍️ НОВЫЙ ЗАКАЗ",
      "",
      `👤 Клиент: ${name}`,
      `📱 Телефон: ${phone}`,
      `📍 Адрес: ${address}`,
      tg,
      "",
      "📦 Товары:",
      lines,
      "",
      `💰 Итого: ${total} сом`,
      `🎁 Бонусы: ${bonuses}`
    ].join("\n");

    const response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text,
        disable_web_page_preview: true
      })
    });

    const result = await response.json().catch(() => ({}));
    if (!response.ok || !result.ok) {
      return res.status(502).json({ error: "Telegram send failed" });
    }

    return res.status(200).json({ ok: true });
  } catch (e) {
    return res.status(500).json({ error: "Server error" });
  }
}
